package newClient;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import util.NetworkUtil;

import java.util.ArrayList;
import java.util.List;

public class WheatController {
    private Main main;
    private NetworkUtil nc;
    private List<String> wheatList;
    private List<String> productIdList=new ArrayList<>();
    @FXML
    private TextArea WheatListArea;
    @FXML
    private Button addButton;

    @FXML
    private Button backButton;

    @FXML
    private TextField CropsType;

    @FXML
    private TextField ProductId;

    @FXML
    private Button buyButton;

    @FXML
    void addButtonAction(ActionEvent event) {
        try {
            main.showAddItem("rice");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void backButtonAction(ActionEvent event) {
        try {
            main.showCropsHomePage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void buyButtonAction(ActionEvent event) {
        String productId=ProductId.getText();
        if (productIdList.contains(productId))
        {
                nc.write("buybutton" + Client.token + "wheat" + Client.token + productId+Client.token+main.getName());
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Thanks for buying");
                alert.setHeaderText("Enjoy fresh crpos directly from fermer");
                alert.setContentText("Enjoy shopping");
                alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Incorrect ProductId");
            alert.setHeaderText("Product ID is Invalid");
            alert.setContentText("Give a valid product Id");
            alert.showAndWait();
        }
    }
    void loadWheatList()
    {
        WheatListArea.setEditable(true);
        nc.write("sendlist"+Client.token+"wheat");
        wheatList=(ArrayList<String>)nc.read();
        WheatListArea.clear();
        for (String t:wheatList ) {
            String[] strings=t.split(Client.token);
            if (strings.length==6)
            {
                WheatListArea.appendText("Farmer's Name : "+strings[0]+"\n"+"Product Id : "+strings[1]+"\n"+
                        "Mobile Number : "+ strings[2]+"\n"+"Wheat Type : "+strings[4]+"\n"+"Price : "+strings[3]+"\n"+
                        "Stock weight : "+strings[5]+" KG"+"\n\n\n");
                productIdList.add(strings[1]);
            }
        }
        WheatListArea.setEditable(false);
        System.out.println(wheatList);
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public void setNc(NetworkUtil nc) {
        this.nc = nc;
    }
}
/*
{
        String productId=ProductId.getText();
        if (productIdList.contains(productId))
        {
//            boolean flag=true;
//            try {
                int myProductId=Integer.parseInt(productId);
//            } catch (NumberFormatException e) {
//                flag=false;
//                e.printStackTrace();
//            }
//            if (flag) {
                nc.write("buybutton" + Client.token + "wheat" + Client.token + productId);
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Than");
                alert.setHeaderText("Product ID isn't recognised by server");
                alert.setContentText("Give another valid product Id");
                alert.showAndWait();
//            }
//            else
//            {
//                Alert alert = new Alert(Alert.AlertType.ERROR);
//                alert.setTitle("System problem");
//                alert.setHeaderText("Product ID isn't recognised by server");
//                alert.setContentText("Give another valid product Id");
//                alert.showAndWait();
//            }

        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Incorrect ProductId");
            alert.setHeaderText("Product ID is Invalid");
            alert.setContentText("Give a valid product Id");
            alert.showAndWait();
        }
    }
 */