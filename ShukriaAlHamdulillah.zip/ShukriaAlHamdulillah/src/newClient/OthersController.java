package newClient;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import sun.awt.datatransfer.DataTransferer;
import util.NetworkUtil;

import java.util.ArrayList;
import java.util.List;

public class OthersController {
    private Main main;
    private NetworkUtil nc;
    private List<String> productIdList=new ArrayList<>();
    private List<String> othersList;

    public void setMain(Main main) {
        this.main = main;
    }

    public void setNc(NetworkUtil nc) {
        this.nc = nc;
    }

    @FXML
    private TextArea CropList;

    @FXML
    private Button addButton;

    @FXML
    private Button backButton;


    @FXML
    private TextField CropsType;

    @FXML
    private TextField ProductId;

    @FXML
    private Button buyButton;



    @FXML
    void addButtonAction(ActionEvent event) {
        try {
            main.showAddItem("others");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void backButtonAction(ActionEvent event) {
        try {
            main.showCropsHomePage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void buyButtonAction(ActionEvent event) {
        String productId=ProductId.getText();
        System.out.println(productIdList);
        if (productIdList.contains(productId))
        {
            nc.write("buybutton" + Client.token + "others" + Client.token + productId+Client.token+main.getName());
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Thanks for buying");
            alert.setHeaderText("Enjoy fresh crpos directly from fermer");
            alert.setContentText("Enjoy shopping");
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Incorrect ProductId");
            alert.setHeaderText("Product ID is Invalid");
            alert.setContentText("Give a valid product Id");
            alert.showAndWait();
        }
    }

    void loadOthersList()
    {
        CropList.setEditable(true);
        nc.write("sendlist"+Client.token+"others");
        othersList =(ArrayList<String>)nc.read();
        for (String t:othersList ) {
            String[] strings=t.split(Client.token);
            if (strings.length==7)
            {
                CropList.appendText("Crops Type : "+strings[0]+"\n"+"Farmer's Name : "+strings[1]+"\n"+"Product Id : "+strings[2]+"\n"+
                        "Mobile Number : "+ strings[3]+"\n"+"Crop Type : "+strings[5]+"\n"+"Price : "+strings[4]+"\n"+
                        "Stock weight : "+strings[6]+" KG"+"\n\n\n");
                productIdList.add(strings[2]);
            }
        }
        System.out.println(othersList);
        CropList.setEditable(false);
    }

}