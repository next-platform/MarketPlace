package newClient;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import util.NetworkUtil;

import java.util.ArrayList;
import java.util.List;

public class MaizeController {

    private Main main;
    private NetworkUtil nc;
    private List<String> maizeList;
    private List<String > productIdList=new ArrayList<>();

    @FXML
    private TextArea MaizeList;

    @FXML
    private Button addButton;

    @FXML
    private Button backButton;


    @FXML
    private TextField CropsType;

    @FXML
    private TextField ProductId;

    @FXML
    private Button buyButton;

    @FXML
    void addButtonAction(ActionEvent event) {
        try {
            main.showAddItem("maize");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void buyButtonAction(ActionEvent event) {
        String productId=ProductId.getText();
        if (productIdList.contains(productId))
        {
            nc.write("buybutton" + Client.token + "maize" + Client.token + productId+Client.token+main.getName());
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Thanks for buying");
            alert.setHeaderText("Enjoy fresh crpos directly from fermer");
            alert.setContentText("Enjoy shopping");
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Incorrect ProductId");
            alert.setHeaderText("Product ID is Invalid");
            alert.setContentText("Give a valid product Id");
            alert.showAndWait();
        }
    }
    @FXML
    void backButtonAction(ActionEvent event) {
        try {
            main.showCropsHomePage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    void loadMaizeList()
    {
        MaizeList.setEditable(true);
        nc.write("sendlist"+Client.token+"maize");
        maizeList =(ArrayList<String>)nc.read();
        for (String t:maizeList ) {
            String[] strings=t.split(Client.token);
            if (strings.length==6)
            {
                MaizeList.appendText("Farmer's Name : "+strings[0]+"\n"+"Product Id : "+strings[1]+"\n"+
                        "Mobile Number : "+ strings[2]+"\n"+"MaizeType : "+strings[4]+"\n"+"Price : "+strings[3]+"\n"+
                        "Stock weight : "+strings[5]+" KG"+"\n\n\n");
                productIdList.add(strings[1]);
            }
        }
        System.out.println(maizeList);
        MaizeList.setEditable(false);

    }
    void setMain(Main main)
    {
        this.main=main;
    }

    public void setNc(NetworkUtil nc) {
        this.nc = nc;
    }

}
