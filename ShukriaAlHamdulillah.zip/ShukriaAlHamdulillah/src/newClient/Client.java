package newClient;

public class Client {
    static String token="/ /";
    /*NetworkUtil nc;
    Main Mymain;
    public Client(String serverAddress, int serverPort) {
        String serverAddress = "127.0.0.1";
        int serverPort = 55555;
        try {
//            System.out.print("Enter name of the client: ");
//            Scanner scanner = new Scanner(System.in);
//            String clientName = scanner.nextLine();
            Main client = new Main(serverAddress, serverPort);
            nc = new NetworkUtil(serverAddress, serverPort);
              Mymain=new Main(this,nc,args);
//            nc.write(clientName);
//            new ReadThread(nc);
//            new WriteThreadClient(nc, clientName);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[]) {

        Client client = new Client(serverAddress, serverPort,args);

    }*/
}